<template>
    <div class="description">
        AVELO is the hearth of the restaurant, providing nourishment & comfort. 
        <br><br>
        Shelter from the bustling world outside & let us look after you. 
        <br><br>
        Serving breakfast, lunch & dinner, a sizeable a la carte menu
        showcases the very best seasonal offerings.
        <br><br>
        Everything is made in-house wherever possible: from charcuterie & bread to jams,
        juices and pickles.
        <br><br> 
        Attentive but informal, simple but sophisticated.
    </div>
</template>





<style scoped>

</style>