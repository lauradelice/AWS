<template>
    <div class="conteiner">
        
        <ul class="menu">
            <li class="menu_item"><a href="#" class="menu_link">HOME</a></li>
            <li class="menu_item"><router-link to="/about_us" class="menu_link">ABOUT US</router-link></li>
            <li class="menu_item"><router-link to="/voucher" class="menu_link">GIFT VOUCHERS</router-link></li>
            <li class="menu_item"><router-link to="/team" class="menu_link">TEAM</router-link></li>
            <li class="menu_item"><router-link to="/contact" class="menu_link">CONTACTS</router-link></li>
           
            
            
        </ul>
        <div class="Logo">
        <img src="img/дерево олива 1.png" alt="Logo" width="130" height="104">
        </div>
    </div>
</template>

<script>

</script>

<style scoped>

</style>
