<template>
     <div class="main_menu">

        <div class="content">
            
            <div class="descriptoon">
                <h3>A LA CART</h3>
                <div>
                <img src="img/Rectangle 4.png" width=350 height=340>
                </div> 
                            
                <div class="timetable">
                    An extensive a la carte menu is served every day on the ground floor. Be it a light bite from the grazing menu, long lunch or celebratory dinner; there is something for everyone.
                    <br>
                    Reflective of HIDE’s signature style and lightness of touch, dishes are simple, seasonal, nourishing & delicious.
                    <br>
                    MONDAY - THURSDAY:
                    <br>
                    12:00PM - 2:15PM & 6:00PM - 9:30PM
                    <br>
                    FRIDAY:
                    <br>
                    12:00PM - 2:15PM & 6:00PM - 10:00PM
                    <br>
                    SATURDAY:
                    <br>
                    12:30PM - 2:45PM & 6:00PM - 10:00PM
                    <br>
                    SUNDAY:
                    <br>
                    12:30PM - 2:45PM & 6:00PM - 9:15PMA 
                </div>  
                
                <router-link to="/alacard" class="catalog_link">LA CARTE</router-link>
                
            </div>
        </div>   
        <div class="content">
            
            <div class="descriptoon">
                <h3>BREAKFAST</h3>
                <div>
                <img src="img/завтрак 1.png" width=350 height=340>
                </div>
                <div class="timetable"> 
                    Breakfast at AVELO is fresh, light, healthy & like no other.
                    <br>
                    A tranquil refuge from busy mornings in our light-filled dining room, the perfect start to your day.
                    <br>
                    Served every day alongside premium roast single origin Union coffees & Mariage Frères teas.
                    <br>
                    Our open bakery serves signature breads & viennoiseries, freshly baked each morning.
                    <br>
                    MONDAY - FRIDAY:
                    <br>
                    7:30AM - 10:15AM
                    <br>
                    SATURDAY & SUNDAY:
                    <br>
                    9:00AM - 11AM
                </div> 
                
                <router-link to="/breakfast" class="catalog_link">BREAKFAST</router-link>
            </div>
        </div>   
        <div class="content">
            
            <div class="descriptoon">
                <h3>LUNCH</h3>
                <div>
                <img src="img/ланч1 1.png" width=350 height=340>
                </div> 
                <div class="timetable">
                    A frequently changing seasonal set lunch, available every day & easily enjoyed within an hour.
                    <br>
                    MONDAY - FRIDAY:
                    <br>
                    12:00PM - 2:15PM
                    <br>                
                    SATURDAY & SUNDAY:
                    <br>
                    12:30PM - 2:45PM
                  
                </div>               

                <router-link to="/lunch" class="catalog_link">SET LUNCH MENU</router-link>               
                
            </div>
        </div>   
        <div class="content">
            
            <div class="descriptoon">
                <h3>WINE LIST</h3>
                <div>
                <img src="img/вино 1.png" width=350 height=340>
                </div> 
                <div class="timetable">
                    Browse a wide range of bottles from different regions.
                    <br>
                    Our sommelier team is ready to recommend the perfect complement to your meal in advance or in the restaurant.
                </div> 
                             
                <router-link to="/wine" class="catalog_link">BROWSE WINE</router-link> 
                
            </div>
        </div>  
        
        
    </div>
</template>

