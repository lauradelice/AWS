<template>
    <div>
          
        <h1 class="animate__animated animate__rotateIn">
            AVELO
        </h1>
        
        <Carousel></Carousel>
        
    </div>
</template>




<script lang="ts">
import Carousel from "./Carousel.vue";




export default {
  name: "Avelo",
  components: {
    Carousel,

    
      
  },
  
 
   
  

};

 
</script>