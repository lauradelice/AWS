<template>
   
    <div class="gallery">
        <h2>
            GALLERY
        </h2>
        

        <div class="gallery_pict">
            
                       
            <div class="pict">
                <img src="img\Gallery\coffee-gecea66a73_1280.jpg">
            </div>
            <div class="pict">
                <img src="img/Gallery/10 1.png">
            </div>
            <div class="pict">
                <img src="img\Gallery\food-g65d7b8654_1280.jpg">
            </div>
            <div class="pict">
                <img src="img\Gallery\salmon-g841851d91_1280.jpg">
            </div>
            <div class="pict">
                <img src="img\Gallery\HIDE_7 1.png">
            </div>
            <div class="pict">
                <img src="img\Gallery\platter-g9f1721a1b_1280.jpg">
            </div>
            <div class="pict">
                <img src="img\Gallery\pancakes-g8a66f0d57_1280.jpg">
            </div>
            <div class="pict">
                <img src="img\Gallery\food-g134bc3515_1280.jpg">
            </div>
            <div class="pict">
                <img src="img\Gallery\drink-g255636448_1280.jpg">
            </div>
            <div class="pict">
                <img src="img\Gallery\drink-g61b14152d_1280.jpg">
            </div>
                      
                     
        </div> 
        

    </div>
</template>

<script>

</script>

<style scoped>

</style>