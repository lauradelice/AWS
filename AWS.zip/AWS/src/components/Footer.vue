<template>
    <div class="footer">
        <div class="Logo">
            <img src="img/дерево олива 1.png" alt="Logo" width="130" height="104">
        </div> 
        <ul class="menu_footer">
            <li class="menu_item"><a href="#" class="menu_link">HOME</a></li>
            <li class="menu_item"><router-link to="/book" class="menu_link">BOOK</router-link></li>
            <li class="menu_item"><router-link to="/team" class="menu_link">TEAM</router-link></li>
            <li class="menu_item"><router-link to="/contact" class="menu_link">CONTACTS</router-link></li>
        </ul>

    </div>
</template>


