<template>
  <div>
    <h3>BREAKFAST MENU</h3> 
    <div class="main_menu">
      
      
      

      <div class="breakfast_card">
                        
        <img src="img\breakfast\1.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">
            Brioche with smoked salmon and avocado mousse
        </div> 

        <div class="breakfast_price">
            18 BYR
        </div>  
                
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\breakfast\2.jpg" width="300" height="300">
                                    
        <div class="menu_descr">
            Granola with wild berry yoghurt
        </div> 

        <div class="breakfast_price">
            9 BYR
        </div>  
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\breakfast\3.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">
            Omelet with mushrooms and bacon
        </div> 

        <div class="breakfast_price">
            13 BYR
        </div>  
                  
      </div>      
      <div class="breakfast_card">
                        
        <img src="img\breakfast\4.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Croissant with smoked salmon and cheese
        </div> 

        <div class="breakfast_price">
            10 BYR
        </div>  
                
      </div>  

      <div class="breakfast_card">
                        
        <img src="img\breakfast\5.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Croissant with nutella and banana
        </div> 

        <div class="breakfast_price">
            9 BYR
        </div>  
                
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\breakfast\6.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Frittata
        </div> 

        <div class="breakfast_price">
            14 BYR
        </div>  
                
      </div> 

              
    </div>
  </div>
</template>
