<template>
  <div class="about_us">
    <h2 class="animate__animated animate__zoomInDown">About Us</h2>
    <p>Italian cuisine restaurant with an author's vision in the very center of Minsk. The institution is distinguished by a rich and varied menu, as well as a special relaxing atmosphere and a wonderful view of the Freedom Square street.
    <br><br>
    AVELO restaurant is decorated in Italian style. The laconic and discreet interior is elegantly complemented by decorative elements. In warmer months, guests can sit on the spacious summer terrace, which offers a picturesque view of the historic city center. There is a special terrace menu from the Chef.
    <br><br>
    AVELO restaurant is a special world with its own charm and flavor. Getting here, you seem to be transported to a leisurely and refined Italy.     
    <br><br>
    In the design of the restaurant, we tried to recreate the national style, which helps to plunge into the atmosphere of this popular country. Everything is quite simple, democratic, cheerful, pleasant in Italian. Comfortable sofas, soft chairs, brick walls and an excellent view from the windows - everything is conducive to relaxation and pleasant communication with colleagues, friends and family.
    <br><br>
    Italy is a country where home cooking, family spirit and vibrant tastes are appreciated. Every meal is a real pleasure. Italian cuisine is based on the freshness of products and the simplicity of their preparation, it unleashes the potential of products and is always ready to surprise with new tastes and aromas.
    <br><br>
    Italian cuisine is very different, there are always many colors and surprises in it, and in our restaurant we have collected the best dishes from different regions of Italy.
    <br><br>
    When visiting our restaurant, be sure to taste the chef's specialties. Popular national delicacies: fetuccini, risotto. Numerous salads and appetizers are prepared here according to a special secret recipe, thanks to which they acquire their zest at AVELO. Those who dropped by to enjoy pizza will find a wide selection of 10 items. Our wine list is quite varied, which was compiled according to the principle of "only the best", for every taste and mood at the most democratic prices.
    <br><br>
    AVELO is a great place for romantic dates, long-awaited friendly meetings, children's and family holidays.
    <br><br>
    We are always looking forward to welcoming you and sincerely believe that AVELO will become a friend of each of our guests, because you don't need a special occasion to visit us.
    </p>

    <h2>About the chef</h2>

    
    <img src="img\chef\rabota-povarom-za-granicei.jpg" class="lefting" width="630" height="414">
    
    <p>
    The chef of AVELO is a native Italian Tommaso d'Amato. Born and raised in southern Italy, in the Sicily region.
    <br><br>
    He studied at the Hotel Management School, F. Martini di Castiglioncello, has a HACCP certificate. Taught culinary arts at Italian universities (Perugia, Milan, Pistoia, Brescia, Trento).
    <br><br>
    Took part in various exhibitions around the world (Milan show host conazinede, Sigep-fair of Rimini, Fair-grass, Salone del Mobile in Milan (kitchen-aid).
    <br><br>
    He was a Chef and helped to establish cuisine in many restaurants and hotels throughout Italy (Siena, Turin, Cinzano, Genova, Monte Amiata, Cuneo, Como, Venice, Livorno). Consulting restaurants in Germany and France.
    <br><br>
    Tommaso d'Amato uses not only the classic recipes of European cuisine, he also brings the author's touches to the dishes and develops his own recipes. Through the dishes that Tommaso prepares, he expresses his emotions and feelings.
    </p>


    
    
    

  </div>
</template>

