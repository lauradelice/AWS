<template>
  <div class="contact">
    
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2350.5504525523374!2d27.554065915259248!3d53.904193780099654!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46dbcfeafab2d951%3A0x519e4d9dcb6f554a!2z0L_Quy4g0KHQstC-0LHQvtC00YsgNiwg0JzQuNC90YHQug!5e0!3m2!1sru!2sby!4v1636733952280!5m2!1sru!2sby" width="100%" height="670" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    <div class="contact_info">
      <div class="contact_name animate__animated animate__fadeInRight">AVELO</div>
      <div class="contact_addr animate__animated animate__fadeInLeft">Address: Svobody, 6, MINSK</div>
      <div class="contact_addr animate__animated animate__fadeInRight">Monday - Sunday: from 12-00 to 01-00</div>
      <a class="contact_phone animate__animated animate__fadeInLeft" href="tel:+375292647798">+375 (29) 264 77 98</a>
    </div>

    

  </div>
</template>
