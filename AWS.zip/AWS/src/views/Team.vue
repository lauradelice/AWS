<template>
  
  <div class="team">

    
   
    <h2 class="animate__animated animate__rubberBand">Our team</h2>
    <div class="team_subtitle">The best experts in Italian cuisine</div>
    <div class="team_img">
            <img src="img\team\1234.jpg">
    </div>
    <div class="team_deskr">This is our team. Our team consists of specialists competent in their field. Their main goal is to do their job so that the result fully meets the expectations of the guests and even pleasantly surprises them. Each of the team strives to convey to the visitors all the atmosphere and hospitality of Italian culture. Our goal is to prepare delicious, traditional Italian cuisine, as well as to provide impeccable service and attentive service.
With our work, we want to delight each of our visitors. We guarantee all clients that the time spent in our establishment will be distinguished by a special warmth and exquisite taste.</div>
    

    <div class="staff_conteiner">
      <div class="staff"> 
        <div class="staff_name">Maria</div>
        <div class="staff_position">Hostess</div>
        <div class="staff_desсr">Maria, our charming hostess, instantly melts the coldest and most arrogant hearts. (Although these are almost never found among our guests). It is very important to be able to set a positive mood on the doorstep. Agree, it's nice when you are shown into the hall and seated by such a nice, invariably polite and cheerful employee.</div>
      </div>

      <div class="staff"> 
        <div class="staff_name">Tommaso d'Amato</div>
        <div class="staff_position">Сhief-cooker</div>
        <div class="staff_desсr">The highly qualified chef Tommaso d'Amato indigenous Italian, Born and raised in southern Italy, in the Sicily region. He is responsible for the selection of products and the preparation of delicious Italian dishes. Dishes made by him turn into real masterpieces. They have a harmonious and refined taste, as well as a very appetizing appearance. No one will remain indifferent to such an unsurpassed combination. </div>
      </div>

      <div class="staff"> 
        <div class="staff_name">Oksana Anisimova</div>
        <div class="staff_position">Sous chef</div>
        <div class="staff_desсr">Oksana Anisimova, our sous-chef, is always focused and accurate, not being distracted by extraneous matters. Here she conjures over the dessert "Sakrat Maryssenki", but she also prepares all the other dishes with the same inspiration and precision, but does not forget to make important improvements to the recipe from time to time.</div>
      </div>

      <div class="staff"> 
        <div class="staff_name">Catherine</div>
        <div class="staff_position">Waiter</div>
        <div class="staff_desсr">The waiters of the establishment always look neat, and the guests are greeted warmly and in a good mood. They are experienced, attentive and friendly people who take care of every day to make the visitor feel in a hospitable and pleasant place. The guest should always be satisfied - this is the main goal of serving the establishment. Our waiters take into account the wishes of each visitor and are always responsible for their work.</div>
      </div>

      <div class="staff"> 
        <div class="staff_name">Tatiana Nikolaevna</div>
        <div class="staff_position">Cloakroom attendant</div>
        <div class="staff_desсr">The theater begins with a coat rack. If we consider our restaurant a gastronomic theater, then we are no exception. Many of our guests get their first impression of the restaurant in the wardrobe, from communication with the always smiling and friendly Tatyana Nikolaevna and then remember her with warmth. Because they understand that this smile and delicacy are genuine. Not "well-trained" but sincere.</div>
      </div>

      <div class="staff"> 
        <div class="staff_name">Alexander Bely</div>
        <div class="staff_position">PR Manager</div>
        <div class="staff_desсr">Alexander Bely, an involved consultant, has been working with us since the very foundation of the restaurant, so he can rightfully be considered a member of the team. Doctor of Humanities (PhD) Has been dealing with the history of Italian cuisine for 20 years, since 1999 author of about 200 articles in various media on this topic, as well as books widely known in the country.</div>
      </div>
    </div>

    
  </div>

 
 
</template>
