<template>
  <div>
    <h3>WINE LIST</h3> 
    <div class="main_menu">

      <div class="wine_menu">
        <img src="img\wine_list\2021-10-vine_Chapl_03-1.jpg">
      </div>

    </div>
        
        
        
  </div>
</template>
