<template>
  <div>
    <h3>LUNCH MENU</h3> 
    <div class="main_menu">
      
      
      

      <div class="breakfast_card">
                        
        <img src="img\lunch\1.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">
            Salad with tuna
        </div> 

        <div class="breakfast_price">
            22 BYR
        </div>  
                
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\lunch\2.jpg" width="300" height="300">
                                    
        <div class="menu_descr">
            Shrimp and squid salad with mango sauce
        </div> 

        <div class="breakfast_price">
            25 BYR
        </div>  
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\lunch\3.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">
            Vegetarian salad
        </div> 

        <div class="breakfast_price">
            18 BYR
        </div>  
                  
      </div>      
      <div class="breakfast_card">
                        
        <img src="img\lunch\4.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Spaghetti carbonara
        </div> 

        <div class="breakfast_price">
            20 BYR
        </div>  
                
      </div>  

      <div class="breakfast_card">
                        
        <img src="img\lunch\5.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Spaghetti with seafood
        </div> 

        <div class="breakfast_price">
            35 BYR
        </div>  
                
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\lunch\6.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Risotto with seafood
        </div> 

        <div class="breakfast_price">
            34 BYR
        </div>  
                
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\lunch\7.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Creamy tomato soup
        </div> 

        <div class="breakfast_price">
            13 BYR
        </div>  
                
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\lunch\8.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Gazpacho Soup
        </div> 

        <div class="breakfast_price">
            12 BYR
        </div>  
                
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\lunch\9.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Pea and Leek Cream Soup
        </div> 

        <div class="breakfast_price">
            12 BYR
        </div>  
                
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\lunch\10.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Chicken fillet in white wine with asparagus
        </div> 

        <div class="breakfast_price">
            20 BYR
        </div>  
                
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\lunch\11.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Fillet of salmon with pistachio crust
        </div> 

        <div class="breakfast_price">
            39 BYR
        </div>  
                
      </div> 

      <div class="breakfast_card">
                        
        <img src="img\lunch\12.jpg" width="300" height="300">
                
                          
        <div class="menu_descr">          
            Sicilian cod
        </div> 

        <div class="breakfast_price">
            34 BYR
        </div>  
                
      </div> 

              
    </div>
    
  </div>

</template>
