<template>
<div>
  <div class="main_menu"> 
   
    
		<h3>COLD SNACKS</h3>
    <div class="alacard">
      
      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\1.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Bruschetta with parma and sun-dried tomatoes</div>
        <div class="menu-price">15 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\2.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Trout carpaccio with capers</div>
        <div class="menu-price">18 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\3.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Beef carpaccio with parmesan</div>
        <div class="menu-price">15 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\4.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Pink tuna tartar</div>
        <div class="menu-price">19 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\5.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Beef tartar with a sprig of raspberry</div>
        <div class="menu-price">22 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\6.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Meat present</div>
        <div class="menu-price">25 BYR</div>
      </div>
    </div>

    <h3>SALADS</h3>
    <div class="alacard">
      
      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\7.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Vegetable with FETAKI</div>
        <div class="menu-price">11 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\8.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">"CAESAR" with chicken fillet</div>
        <div class="menu-price">11 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\9.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">"CALABRIA"</div>
        <div class="menu-price">12 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\10.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Beef slices with warm mazzarella and ginger-soy sauce</div>
        <div class="menu-price">16 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\11.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Arugula with avocado, cherry and pine nuts</div>
        <div class="menu-price">15 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\12.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">"COLOSEUM" with salmon, avocado and sweet and sour sauce</div>
        <div class="menu-price">15 BYR</div>
      </div>
		
      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\13.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Pink tuna with arugula and warm BRI cheese</div>
        <div class="menu-price">18 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\14.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Salad with shrimps, mushrooms and pine nutse</div>
        <div class="menu-price">17 BYR</div>
      </div>
       
		</div>
		
	
		     

		<h3>SOUPS</h3>
			
	
          
    <div class="alacard"> 
          
      <div class="menu_conteiner">
        <div>
        <img src="img\alacard\15.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">"MINESTRONE" vegetable soup with parmesan</div>
        <div class="menu-price">7 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
        <img src="img\alacard\16.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Onion soup with croutons</div>
        <div class="menu-price">6 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
        <img src="img\alacard\17.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Warm tomato soup with bacon and beans</div>
        <div class="menu-price">5 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
        <img src="img\alacard\18.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Solyanka meat</div>
        <div class="menu-price">7 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
        <img src="img\alacard\19.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Prawn sous-puree with shrimps and parmesan</div>
        <div class="menu-price">8 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
        <img src="img\alacard\20.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Soup with porcini mushrooms, chanterelles and beef slices</div>
        <div class="menu-price">12 BYR</div>
      </div>
        
    </div>  

    <h3>PASTE</h3>
    <div class="alacard">
      
      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\21.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Meaty lasagna</div>
        <div class="menu-price">11 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\22.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Spaghetti "CARBONARA"</div>
        <div class="menu-price">13 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\23.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Tagliatelle with mussels and shrimps</div>
        <div class="menu-price">21 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\24.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Spaghetti with beef in arabiato sauce</div>
        <div class="menu-price">16 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\25.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Fish lasagna</div>
        <div class="menu-price">19 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\26.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Tagliatelle with seafood</div>
        <div class="menu-price">18 BYR</div>
      </div>
    </div>

    <h3>FISH AND SEAFOOD DISHES</h3>
    <div class="alacard">
    
      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\27.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Pink tuna in sesame seeds with arugula leaves</div>
        <div class="menu-price">27 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\28.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Pink tuna with rammarine in a spicy sauce</div>
        <div class="menu-price">26 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\29.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Trout in crispy sesame</div>
        <div class="menu-price">27 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\30.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Trout in creamy cheese sauce</div>
        <div class="menu-price">27 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\31.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Salmon with shrimps and green pea puree</div>
        <div class="menu-price">27 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\32.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Steamed salmon with thyme</div>
        <div class="menu-price">27 BYR</div>
      </div>
    </div>

    <h3>MEAT DISHES</h3>
    <div class="alacard">
    
      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\33.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Beef medallion with cherry-wine sauce</div>
        <div class="menu-price">21 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\34.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Beef tenderloin with boletus</div>
        <div class="menu-price">25 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\35.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Turkey fillet with apples and cranberry sauce</div>
        <div class="menu-price">19 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\36.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Pork medallions with chanterelles in creamy ginger sauce</div>
        <div class="menu-price">19 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\37.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Grilled turkey fillet with porcini mushroom sauce</div>
        <div class="menu-price">27 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\38.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Grilled chicken fillet with dor blue and sun-dried tomatoes</div>
        <div class="menu-price">18 BYR</div>
      </div>
  

    </div>

    <h3>DESSERTS</h3>
    <div class="alacard">
    
      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\39.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">"TIRAMISU"</div>
        <div class="menu-price">9 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\40.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Lemon Shekolade Cream Cake</div>
        <div class="menu-price">7 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\41.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Napoleon cake</div>
        <div class="menu-price">8 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\42.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Apple-cherry strudel</div>
        <div class="menu-price">8 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\43.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Chocolate bar "Curd"</div>
        <div class="menu-price">9 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\44.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Aromatic pear in puff pastry with almond and shecolade</div>
        <div class="menu-price">10 BYR</div>
      </div>
  

    </div>

      
    <h3>BEVERAGES</h3>
    <div class="alacard">
    
      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\45.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">7UP</div>
        <div class="menu-price">3 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\46.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">PEPSI</div>
        <div class="menu-price">3 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\47.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">MIRINDA</div>
        <div class="menu-price">3 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\48.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Cranberry juice</div>
        <div class="menu-price">3 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\49.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Mulled wine non-alcoholic</div>
        <div class="menu-price">4 BYR</div>
      </div>

      <div class="menu_conteiner">
        <div>
          <img src="img\alacard\50.jpg" width="170" height="170">
        </div>  
        <div class="menu-descr">Bonaqua still</div>
        <div class="menu-price">2 BYR</div>
      </div>
  

    </div>
      
    

    
    

  </div>
</div>
</template>
